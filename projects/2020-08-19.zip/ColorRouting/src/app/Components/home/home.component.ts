import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {HelloService} from "../../Services/hello.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  result = "";
  constructor(private router: Router,
              private helloService: HelloService) { }

  ngOnInit(): void {
  }

  go(arg){
    this.router.navigate([arg])
      .then(res => {
        if(!res) {
          this.result = "Access denied";
          setTimeout(()=>this.result="", 2000);
        }
      });
  }

  sayHello(msg){
    this.helloService.helloSubject.next(msg);
  }

}
