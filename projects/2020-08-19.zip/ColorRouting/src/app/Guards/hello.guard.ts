import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import {HelloService} from "../Services/hello.service";

@Injectable({
  providedIn: 'root'
})
export class HelloGuard implements CanActivate {

  role = "";
  constructor(private helloService: HelloService){
    this.helloService.helloSubject.subscribe(res => this.role=res);
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return next.data.roles.includes(this.role);
  }
  
}
