import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from "./Components/home/home.component";
import {RedComponent} from "./Components/red/red.component";
import {GreenComponent} from "./Components/green/green.component";
import {BlueComponent} from "./Components/blue/blue.component";
import {HelloGuard} from "./Guards/hello.guard";

const routes: Routes = [
  {path: "home", component: HomeComponent},
  {path: "red", component: RedComponent, canActivate: [HelloGuard], data: {roles: ['admin']}},
  {path: "green", component: GreenComponent, canActivate: [HelloGuard], data: {roles: ['admin','manager']}},
  {path: "blue", component: BlueComponent, canActivate: [HelloGuard], data: {roles: ['admin','manager','user']}},
  {path: "*", component: HomeComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
